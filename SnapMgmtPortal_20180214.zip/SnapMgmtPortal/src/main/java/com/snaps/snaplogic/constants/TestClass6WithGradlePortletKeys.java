package com.snaps.snaplogic.constants;

/**
 * @author gaian
 */
public class TestClass6WithGradlePortletKeys {

	public static final String TestClass6WithGradle = "TestClass6WithGradle";

}