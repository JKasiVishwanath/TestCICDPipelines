package com.snaps.snaplogic.portlet;

import com.snaps.snaplogic.constants.TestClass6WithGradlePortletKeys;

import net.iharder.Base64;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.liferay.portal.kernel.configuration.Configuration;
import com.liferay.portal.kernel.configuration.ConfigurationFactoryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalClassLoaderUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.ProcessAction;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.osgi.service.component.annotations.Component;
import static org.apache.commons.codec.CharEncoding.UTF_8;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * @author gaian
 */
@Component(immediate = true, property = { "com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.instanceable=true", "javax.portlet.display-name=",
		"javax.portlet.init-param.template-path=/", "javax.portlet.init-param.view-template=/Welcome.jsp",
		"javax.portlet.name=" + TestClass6WithGradlePortletKeys.TestClass6WithGradle,
		"javax.portlet.resource-bundle=content.Language",
"javax.portlet.security-role-ref=power-user,user"}, service = Portlet.class)
public class TestClass6WithGradlePortlet extends MVCPortlet {

	private final Log log = LogFactoryUtil.getLog(TestClass6WithGradlePortlet.class);

	public void createUser(ActionRequest request, ActionResponse response) throws IOException, PortletException {
		String userEmailId = ParamUtil.getString(request, "userEmailId");
		String firstName = ParamUtil.getString(request, "firstName");
		String lastName = ParamUtil.getString(request, "lastName");
		String org = ParamUtil.getString(request, "org");
		boolean administrator = ParamUtil.getString(request, "administrator")==""?false:true;
		boolean allow_password_login = ParamUtil.getString(request, "allow_password_login")==""?false:true;
		boolean create_home_directory = ParamUtil.getString(request, "create_home_directory")==""?false:true;
		boolean ui_access = ParamUtil.getString(request, "ui_access")==""?false:true;
		boolean isNewUser = ParamUtil.getBoolean(request, "hdnIsNewUser");

		HttpClient client = HttpClientBuilder.create().build();

		Map<String, Object> jsonValues = new HashMap<String, Object>();
		jsonValues.put("first_name", firstName);
		jsonValues.put("last_name", lastName);
		jsonValues.put("allow_password_login", allow_password_login);
		jsonValues.put("ui_access", ui_access);
		if(isNewUser==true){
			jsonValues.put("email", userEmailId);
			jsonValues.put("organization", org);
			jsonValues.put("administrator", administrator);
			jsonValues.put("create_home_directory", create_home_directory);
		}

		JSONObject json = new JSONObject(jsonValues);

		StringEntity entity = new StringEntity(json.toString());

		Credentials credentials = new UsernamePasswordCredentials("kvishwanath@snaplogic.com", "Pavan@kalyan1");
		Header authenticate = BasicScheme.authenticate(credentials, UTF_8, false);

		HttpResponse response2;

		if(isNewUser == true){	
			String url = "https://elastic.snaplogic.com/api/1/rest/public/users";
			HttpPost post = new HttpPost(url);
			post.setEntity(entity);
			post.setHeader("Content-Type", "application/json");
			post.setHeader(authenticate);
			response2 = client.execute(post);
		}
		else{
			String url = "https://elastic.snaplogic.com/api/1/rest/public/users/"+userEmailId;
			HttpPut put = new HttpPut(url);
			put.setEntity(entity);
			put.setHeader("Content-Type", "application/json");
			put.setHeader(authenticate);
			response2 = client.execute(put);
		}
		int responseCode = response2.getStatusLine().getStatusCode();

		System.out.println("responseCode=> " + response2.getStatusLine().toString());

		if (responseCode == 200) {
			if(isNewUser == true){
				SessionMessages.add(request, "createUserSuccessKey");
			}
			else{
				SessionMessages.add(request, "editUserSuccessKey");

				response.setRenderParameter("failed", "false");
				response.setRenderParameter("userId", userEmailId);
			}
			// result = "Response code -200 "+ " - call is successful";
		} else {
			SessionMessages.add(request, PortalUtil.getPortletId(request) + SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
			if(isNewUser == true){
				SessionErrors.add(request, "createUserErrorKey");

				response.setRenderParameter("administrator", String.valueOf(administrator));
				response.setRenderParameter("create_home_directory", String.valueOf(create_home_directory));
			}
			else{
				SessionErrors.add(request, "editUserErrorKey");
			}
			response.setRenderParameter("failed", "true");
			response.setRenderParameter("userEmailId", userEmailId);
			response.setRenderParameter("firstName", firstName);
			response.setRenderParameter("lastName", lastName);
			response.setRenderParameter("org", org);
			response.setRenderParameter("allow_password_login", String.valueOf(allow_password_login));
			response.setRenderParameter("ui_access", String.valueOf(ui_access));

		}
		response.setRenderParameter("mvcPath", "/User.jsp");
	}

	public void deleteUser(ActionRequest request, ActionResponse response) throws IOException, PortletException {
		String userName = ParamUtil.getString(request, "userName");

		System.out.println("userName=> " + userName);

		HttpClient client = HttpClientBuilder.create().build();
		String url = "https://elastic.snaplogic.com/api/1/rest/public/users/"+userName;
		HttpDelete delete = new HttpDelete(url);

		Credentials credentials = new UsernamePasswordCredentials("kvishwanath@snaplogic.com", "Pavan@kalyan1");
		Header authenticate = BasicScheme.authenticate(credentials, UTF_8, false);
		delete.setHeader(authenticate);
		HttpResponse response2 = client.execute(delete);
		int responseCode = response2.getStatusLine().getStatusCode();

		System.out.println("responseCode=> " + response2.getStatusLine().toString());

		if (responseCode == 200) {
			SessionMessages.add(request, "deleteUserSuccessKey");
			// result = "Response code -200 "+ " - call is successful";
		} else {
			SessionMessages.add(request, PortalUtil.getPortletId(request) + SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
			SessionErrors.add(request, "deleteUserErrorKey");
			// result = "Response code -"+responseCode+ " - call is not
			// successful";}
		}
		response.setRenderParameter("mvcPath", "/UsersViewEmail.jsp");
	}

	/*public void editUser(ActionRequest request, ActionResponse response) throws IOException, PortletException {

		String userEmailId = ParamUtil.getString(request, "userId");

		UsersUtil userUtil = new UsersUtil();
		com.snaps.snaplogic.portlet.User slUser = userUtil.getUserCompleteDetails(userEmailId);
		System.out.println("userEmailId : " + userEmailId);
		request.setAttribute("slUser", slUser);
	}*/

	public void createGroup(ActionRequest request, ActionResponse response) throws IOException, PortletException {
		String groupName = ParamUtil.getString(request, "groupName");
		String org = ParamUtil.getString(request, "org");
		Boolean isNewGroup = ParamUtil.getBoolean(request, "hdnIsNew");
		String[] selectedUsers = ParamUtil.getParameterValues(request, "values");

		Map<String, Object> jsonValues = new HashMap<String, Object>();
		if (isNewGroup == true) {
			jsonValues.put("organization", org);
			jsonValues.put("name", groupName);
		}
		jsonValues.put("members", selectedUsers);

		JSONObject json = new JSONObject(jsonValues);

		HttpClient client = HttpClientBuilder.create().build();
		String newUrl = "https://elastic.snaplogic.com/api/1/rest/public/groups";
		String editUrl = "https://elastic.snaplogic.com/api/1/rest/public/groups/" + org + "/" + groupName;

		Credentials credentials = new UsernamePasswordCredentials("kvishwanath@snaplogic.com", "Pavan@kalyan1");
		Header authenticate = BasicScheme.authenticate(credentials, UTF_8, false);

		StringEntity entity = new StringEntity(json.toString(), "UTF8");
		HttpResponse response2 = null;
		if (isNewGroup == true) {
			HttpPost post = new HttpPost(newUrl);
			post.setEntity(entity);
			post.setHeader("Content-Type", "application/json");
			post.setHeader(authenticate);
			response2 = client.execute(post);
		} else {
			HttpPut put = new HttpPut(editUrl);
			put.setEntity(entity);
			put.setHeader("Content-Type", "application/json");
			put.setHeader(authenticate);
			response2 = client.execute(put);
		}
		int responseCode = response2.getStatusLine().getStatusCode();
		System.out.println("responseCode=> " + response2.getStatusLine().toString());

		if (responseCode == 200 || responseCode == 201) {
			if(isNewGroup == true){
				SessionMessages.add(request, "createGroupSuccessKey");
				response.setRenderParameter("groupName", "");
			}
			else{
				SessionMessages.add(request, "editGroupSuccessKey");

				response.setRenderParameter("failed", "false");
				response.setRenderParameter("groupName", groupName);
			}
		} else {
			SessionMessages.add(request, PortalUtil.getPortletId(request) + SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
			if(isNewGroup == true){
				SessionErrors.add(request, "createGroupErrorKey");
				response.setRenderParameter("groupName", "");
			}
			else{
				SessionErrors.add(request, "editGroupErrorKey");
				response.setRenderParameter("groupName", groupName);
			}
		}
		response.setRenderParameter("mvcPath", "/Group.jsp");

	}

	public void deleteGroup(ActionRequest request, ActionResponse response) throws IOException, PortletException {
		String groupName = ParamUtil.getString(request, "groupName");

		System.out.println("groupName=> " + groupName);

		HttpClient client = HttpClientBuilder.create().build();
		String url = "https://elastic.snaplogic.com/api/1/rest/public/groups/"+"Snap-COE-Development/"+groupName;
		HttpDelete delete = new HttpDelete(url);

		Credentials credentials = new UsernamePasswordCredentials("kvishwanath@snaplogic.com", "Pavan@kalyan1");
		Header authenticate = BasicScheme.authenticate(credentials, UTF_8, false);
		delete.setHeader(authenticate);
		HttpResponse response2 = client.execute(delete);
		int responseCode = response2.getStatusLine().getStatusCode();

		System.out.println("responseCode=> " + response2.getStatusLine().toString());

		if (responseCode == 200) {
			SessionMessages.add(request, "deleteGroupSuccessKey");
		} else {
			SessionMessages.add(request, PortalUtil.getPortletId(request) + SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
			SessionErrors.add(request, "deleteGroupErrorKey");
		}
		response.setRenderParameter("mvcPath", "/GroupsView.jsp");
	}

	public JSONArray getProjectPaths(String orgName){
		log.info("inside getProjectsPaths call");
		String BEARER_TOKEN = "Bearer %s";
		Configuration configuration = ConfigurationFactoryUtil.getConfiguration(PortalClassLoaderUtil.getClassLoader(), "portlet");
		String listProjectsAPI = configuration.get("ListProjectsAPI");
		String token = configuration.get("ListProjectsAPIToken");
		String param1 = configuration.get("param3");
		JSONArray getProjectsPathsResponse = null;
		try {
			HttpClient client = HttpClientBuilder.create().build();
			URIBuilder builder = new URIBuilder(listProjectsAPI);
			builder.setParameter(param1, orgName);
			HttpGet httpGet = new HttpGet(builder.build());
			httpGet.setHeader("Content-Type", "application/json");
			httpGet.setHeader("Authorization", String.format(BEARER_TOKEN, token));
			HttpResponse response = client.execute(httpGet);
			BufferedReader breader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			StringBuilder responseString = new StringBuilder();
			String line = "";
			while ((line = breader.readLine()) != null) {
				responseString.append(line);
			}
			breader.close();	
			log.info("inside getProjectPaths call end");
			log.info(responseString.toString()); 
			getProjectsPathsResponse= new JSONArray(responseString.toString());



		} catch (IOException | URISyntaxException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return getProjectsPathsResponse;
	} 

	/*public void migrateProjectCall(ActionRequest actionRequest, ActionResponse actionResponse)
			throws IOException, PortletException {
		try {

			String sourcePath = ParamUtil.getString(actionRequest, "sourcePath");
			String destinationPath = ParamUtil.getString(actionRequest, "destinationPath");
			String[] asset_types = ParamUtil.getParameterValues(actionRequest, "asset_types", null);
			String async = ParamUtil.getString(actionRequest, "async");
			String duplicate_check = ParamUtil.getString(actionRequest, "duplicate_check");
			boolean asyncCall = (async==null || async=="" )?false:true;
			boolean dup_check = (duplicate_check==null || duplicate_check =="" )?false:true;
			HttpClient client = HttpClientBuilder.create().build();
			String url2 = "https://elastic.snaplogic.com:443/api/1/rest/public/project/migrate/";
			url2= url2+sourcePath;
			url2 = url2.replaceAll(" ", "%20");
			URIBuilder uriBuilder = new URIBuilder(url2);
			URI uri = uriBuilder.build();

			Map< String, Object >jsonValues = new HashMap< String, Object >();

		    jsonValues.put("dest_path", destinationPath);
		    jsonValues.put("asset_types", asset_types);
		    jsonValues.put("async", asyncCall);
		    jsonValues.put("duplicate_check", dup_check);
		    JSONObject json = new JSONObject(jsonValues);			
			HttpPost post2 = new HttpPost(uri);
			StringEntity entity = new StringEntity(json.toString());
			post2.setEntity(entity);
			post2.setHeader("Content-Type", "application/json");

			Credentials credentials = new UsernamePasswordCredentials("kvishwanath@snaplogic.com", "Pavan@kalyan1");
			Header authenticate = BasicScheme.authenticate(credentials, UTF_8, false);
			post2.setHeader(authenticate);
			HttpResponse response2 = client.execute(post2);

			BufferedReader rd2 = new BufferedReader(new InputStreamReader(response2.getEntity().getContent()));

			StringBuffer result2 = new StringBuffer();
			String line2 = "";
			while ((line2 = rd2.readLine()) != null) {
				result2.append(line2);
			}

			System.out.println("*******************" + sourcePath + " --" + destinationPath + "--"
					+ Arrays.toString(asset_types) + "--" + async + "--" + duplicate_check+"--"+asyncCall+"--"+dup_check+"--"+"--"+json.toString()+"--"+result2.toString());

		    actionResponse.setRenderParameter("jspPage", "/Welcome.jsp");


		} catch (Exception e) {

			e.printStackTrace();

		}
	}*/

	public void migrateProjectCall(ActionRequest actionRequest, ActionResponse actionResponse)
			throws IOException, PortletException {
		TestClass6WithGradlePortlet obj=new TestClass6WithGradlePortlet();
		try {

			String sourceOrg = ParamUtil.getString(actionRequest, "SourceOrg");
			String destinationOrg = ParamUtil.getString(actionRequest, "DestinationOrg");
			String sourceProj = ParamUtil.getString(actionRequest, "projectList");
			String destinationProj = ParamUtil.getString(actionRequest, "DestinationProjectList");
			String file = ParamUtil.getString(actionRequest, "File");
			String job = ParamUtil.getString(actionRequest, "Job");
			String account = ParamUtil.getString(actionRequest, "Account");
			String pipeline = ParamUtil.getString(actionRequest, "Pipeline");
			String async = ParamUtil.getString(actionRequest, "AsynchronousCall");
			String duplicate_check = ParamUtil.getString(actionRequest, "DuplicateCheck");
			String projectsSubPath = ParamUtil.getString(actionRequest, "projectsSubPath");
			String projectsSubPathDest = ParamUtil.getString(actionRequest, "projectsSubPathDest");
			String emailNotificationIds=ParamUtil.getString(actionRequest,"emailNotificationIds");

			boolean asyncCall = (async==null || async=="" || async=="false" )?false:true;
			boolean dup_check = (duplicate_check==null || duplicate_check =="" || duplicate_check =="false" )?false:true;

			JSONArray asset_types = new JSONArray();
			if(file!="false")
				asset_types.put(file);
			if(account!="false")
				asset_types.put(account);
			if(job!="false")
				asset_types.put(job);
			if(pipeline!="false")
				asset_types.put(pipeline);

			String destPath="/"+destinationOrg+"/"+destinationProj;
			if(projectsSubPathDest!=null || projectsSubPathDest!="" )
				destPath=destPath+"/"+projectsSubPathDest;


			String sourcePath=sourceOrg+"/"+sourceProj;
			if(projectsSubPath!=null || projectsSubPath!="" )
				sourcePath=sourcePath+"/"+projectsSubPath;

			Map< String, Object >projDetails = new HashMap< String, Object >();

			projDetails.put("destinationOrg", destPath);
			projDetails.put("asset_types", asset_types);
			projDetails.put("async", asyncCall);
			projDetails.put("duplicate_check", dup_check);
			projDetails.put("sourceOrg", sourcePath);
			projDetails.put("emailNotificationIds", emailNotificationIds);
			JSONObject projDetailsJson = new JSONObject(projDetails);						
			log.info("projDetailsJson--"+projDetailsJson);

			obj.sendEmailNotification( projDetailsJson);

			actionResponse.setRenderParameter("jspPage", "/Welcome.jsp");

		} catch (Exception e) {

			e.printStackTrace();

		}
	}
	public void sendEmailNotification(JSONObject projDetailsJson){
		log.info("inside email call");
		String BEARER_TOKEN = "Bearer %s";
		Configuration configuration = ConfigurationFactoryUtil.getConfiguration(PortalClassLoaderUtil.getClassLoader(), "portlet");
		String emailTaskUrl = configuration.get("ProjMigrationEmailTask");
		String token = configuration.get("ProjMigrationEmailTokenTask");
		String param1 = configuration.get("param1");
		String MigrateApi = configuration.get("MigrateApi");
		String param2 = configuration.get("param2");

		try {
			HttpClient client = HttpClientBuilder.create().build();
			URIBuilder builder = new URIBuilder(emailTaskUrl);
			builder.setParameter(param1, projDetailsJson.toString()).setParameter(param2,MigrateApi);
			HttpGet httpGet = new HttpGet(builder.build());
			httpGet.setHeader("Content-Type", "application/json");
			httpGet.setHeader("Authorization", String.format(BEARER_TOKEN, token));
			HttpResponse response = client.execute(httpGet);
			BufferedReader breader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			StringBuilder responseString = new StringBuilder();
			String line = "";
			while ((line = breader.readLine()) != null) {
				responseString.append(line);
			}
			breader.close();	
			log.info("inside email call1");
			log.info(responseString.toString()); 
			System.out.println(responseString.toString());
		} catch (IOException | URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void customProjectMigrationCall(ActionRequest actionRequest, ActionResponse actionResponse)
			throws IOException, PortletException {
		
		log.info("inside customProjectMigrationCall call");
		String BEARER_TOKEN = "Bearer %s";
		Configuration configuration = ConfigurationFactoryUtil.getConfiguration(PortalClassLoaderUtil.getClassLoader(), "portlet");
		String listAssetsAPITask = configuration.get("ListAssetsAPITask");
		String token = configuration.get("ListAssetsTaskToken");
		String param4 = configuration.get("param4");
		String param5 = configuration.get("param5");
		
		try {
			
			String projectPath = ParamUtil.getString(actionRequest, "projectList");
			String AssetType = ParamUtil.getString(actionRequest, "AssetType");
			log.info(AssetType);
			log.info(projectPath);

				HttpClient client = HttpClientBuilder.create().build();
				URIBuilder builder = new URIBuilder(listAssetsAPITask);
				builder.setParameter(param4, projectPath).setParameter(param5, AssetType);
				HttpGet httpGet = new HttpGet(builder.build());
				httpGet.setHeader("Content-Type", "application/json");
				httpGet.setHeader("Authorization", String.format(BEARER_TOKEN, token));
				HttpResponse response = client.execute(httpGet);
				BufferedReader breader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				StringBuilder responseString = new StringBuilder();
				String line = "";
				while ((line = breader.readLine()) != null) {
					responseString.append(line);
				}
				breader.close();	
				log.info("inside customProjectMigrationCall call end");
				log.info(responseString.toString()); 

			
		} catch (Exception e) {

			e.printStackTrace();

		}
		actionResponse.setRenderParameter("jspPage", "/Welcome.jsp");
	}
	
	/*@Override
	public void serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException, PortletException {

		System.out.println("Inside method");
		final String OPERATION_ONE = "serveResourceTest";
		final String OPERATION_TWO = "two";
		final String OPERATION_THREE = "three";

		String resourceId = resourceRequest.getResourceID();
		System.out.println("resourceId : "+resourceId);
		String result = null;

		if (Validator.isNotNull(resourceId)) {
			switch (resourceId) {
			case OPERATION_ONE:
				System.out.println("One");
				result = serveResourceTest(resourceRequest, resourceResponse);
				break;

			case OPERATION_TWO:
				System.out.println("Two");
				result = serveResourceTest(resourceRequest, resourceResponse);
				break;

			case OPERATION_THREE:
				System.out.println("Three");
				result = serveResourceTest(resourceRequest, resourceResponse);
				break;

			default:
				System.out.println("Default");
			}
		} else {
			// report back error that resource id was missing
		}
		resourceResponse.getPortletOutputStream().write(result.getBytes());

		super.serveResource(resourceRequest, resourceResponse);
	}*/

	@Override
	public void serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException, PortletException {
		try {
			System.out.println("aadd");

			/*Configuration configuration = ConfigurationFactoryUtil.getConfiguration(PortalClassLoaderUtil.getClassLoader(), "portlet");
			String userName = configuration.get("User");
			String password = configuration.get("Password");*/

			String resourceID = resourceRequest.getResourceID();
			System.out.println("----resourceID-- "+resourceID);

			if(resourceID.equals("customProjMigration"))
			{
				String orgName = ParamUtil.getString(resourceRequest,"org");
				resourceResponse.setContentType("text/html");
				JSONArray projectsPaths = new JSONArray();
				JSONArray projectsPathsData = new JSONArray();
				TestClass6WithGradlePortlet ts= new TestClass6WithGradlePortlet();
				projectsPaths=ts.getProjectPaths(orgName);

				int length = projectsPaths.length();
				for(int i=0; i<length; i++) {
					JSONObject projectDetails;

					projectDetails = projectsPaths.getJSONObject(i);

					String projectPath = projectDetails.getString("path").toString();
					projectsPathsData.put(projectPath);
				}

				PrintWriter writer = resourceResponse.getWriter();
				writer.print(projectsPathsData);
				writer.flush();
				writer.close();
				System.out.println("Enetered Title is LiferayStack ");
				log.info("------aaa"+orgName);

			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		super.serveResource(resourceRequest, resourceResponse);

	}

	@Override
	public void processAction(ActionRequest actionRequest, ActionResponse actionResponse)
			throws IOException, PortletException {

		super.processAction(actionRequest, actionResponse);
	}

	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {

		super.render(renderRequest, renderResponse);
	}

	public String serveResourceTest(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException, PortletException {

		return "AUI Ajax call is performed";
		/*
		 * resourceResponse.setContentType("text/html"); PrintWriter out =
		 * resourceResponse.getWriter();
		 * out.println("AUI Ajax call is performed"); out.flush();
		 */
		// super.serveResource(resourceRequest, resourceResponse);
	}

}