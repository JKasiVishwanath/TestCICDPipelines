package com.snaps.snaplogic.portlet;

public class User {
	private String email;
	private String first_name;
	private String last_name;
	private boolean user_locked_out;
	private boolean service_account;
	private boolean password_expired;
	private boolean allow_password_login;
	private boolean ui_access;
	private String password_last_updated;
	
	public User() {
		this.email="";
		this.first_name="";
		this.last_name="";
		this.user_locked_out=false;
		this.service_account=false;
		this.password_expired=false;
		this.allow_password_login=false;
		this.ui_access=false;
		this.password_last_updated="";
	}

	public String getPassword_last_updated() {
		return password_last_updated;
	}

	public void setPassword_last_updated(String password_last_updated) {
		this.password_last_updated = password_last_updated;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public boolean isUser_locked_out() {
		return user_locked_out;
	}

	public void setUser_locked_out(boolean user_locked_out) {
		this.user_locked_out = user_locked_out;
	}

	public boolean isService_account() {
		return service_account;
	}

	public void setService_account(boolean service_account) {
		this.service_account = service_account;
	}

	public boolean isPassword_expired() {
		return password_expired;
	}

	public void setPassword_expired(boolean password_expired) {
		this.password_expired = password_expired;
	}

	public boolean isAllow_password_login() {
		return allow_password_login;
	}

	public void setAllow_password_login(boolean allow_password_login) {
		this.allow_password_login = allow_password_login;
	}

	public boolean isUi_access() {
		return ui_access;
	}

	public void setUi_access(boolean ui_access) {
		this.ui_access = ui_access;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "User [email=" + email + ", first_name=" + first_name + ", last_name=" + last_name + ", user_locked_out="
				+ user_locked_out + ", service_account=" + service_account + ", password_expired=" + password_expired
				+ ", allow_password_login=" + allow_password_login + ", ui_access=" + ui_access
				+ ", password_last_updated=" + password_last_updated + "]";
	}
	
}
