package com.snaps.snaplogic.portlet;

import static org.apache.commons.codec.CharEncoding.UTF_8;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.HttpClientBuilder;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.json.JSONException;
//import com.liferay.portal.kernel.json.JSONObject;
import org.json.JSONObject;
import com.liferay.taglib.util.GetUrlTag;

public class UsersUtil {

	public int getCount() {
		Users users = new Users();
		return 0;
	}

	public List<User> viewUsers() {
		Users users = new Users();
		List<User> usersData = new ArrayList<>();
		try {
			Credentials credentials = new UsernamePasswordCredentials("kvishwanath@snaplogic.com", "Pavan@kalyan1");
			Header authenticate = BasicScheme.authenticate(credentials, UTF_8, false);
			HttpClient client4 = HttpClientBuilder.create().build();
			String url = "https://elastic.snaplogic.com:443/api/1/rest/public/groups/" + "Snap-COE-Development"
					+ "/members";
			HttpGet httpGet = new HttpGet(url);
			httpGet.setHeader(authenticate);
			HttpResponse response = client4.execute(httpGet);
			BufferedReader breader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			StringBuilder responseString = new StringBuilder();
			String line = "";
			while ((line = breader.readLine()) != null) {
				responseString.append(line);
			}
			breader.close();
			String responseStr = responseString.toString();

			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

			users = mapper.readValue(responseString.toString(), Users.class);

			for (String userEmailId : users.getMembers()) {
				usersData.add(getUserCompleteDetails(userEmailId));
			}
			/*
			 * System.out.println("The users object data is ");
			 * System.out.println(users.getName());
			 * System.out.println(users.getMembers().size());
			 * System.out.println(users.getMembers());
			 * System.out.println("The users object data is ");
			 * System.out.println("responseStr = " + responseStr);
			 */

		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return usersData;

	}

	public Users viewUsersEmail() {
		Users users = new Users();
		
		try {
			Credentials credentials = new UsernamePasswordCredentials("kvishwanath@snaplogic.com", "Pavan@kalyan1");
			Header authenticate = BasicScheme.authenticate(credentials, UTF_8, false);
			HttpClient client4 = HttpClientBuilder.create().build();
			String url = "https://elastic.snaplogic.com:443/api/1/rest/public/groups/" + "Snap-COE-Development"
					+ "/members";
			HttpGet httpGet = new HttpGet(url);
			httpGet.setHeader(authenticate);
			HttpResponse response = client4.execute(httpGet);
			BufferedReader breader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			StringBuilder responseString = new StringBuilder();
			String line = "";
			while ((line = breader.readLine()) != null) {
				responseString.append(line);
			}
			breader.close();
			
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

			users = mapper.readValue(responseString.toString(), Users.class);
			
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return users;

	}
	
	public static User getUserCompleteDetails(String emailId) {
		User user = new User();
		try {
			Credentials credentials = new UsernamePasswordCredentials("kvishwanath@snaplogic.com", "Pavan@kalyan1");
			Header authenticate = BasicScheme.authenticate(credentials, UTF_8, false);
			HttpClient client4 = HttpClientBuilder.create().build();

			String url = "https://elastic.snaplogic.com:443/api/1/rest/public/users/" + emailId;
			HttpGet httpGet = new HttpGet(url);
			httpGet.setHeader(authenticate);
			HttpResponse response = client4.execute(httpGet);
			BufferedReader breader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			StringBuilder responseString = new StringBuilder();
			String line = "";
			while ((line = breader.readLine()) != null) {
				responseString.append(line);
			}
			breader.close();
			String responseStr = responseString.toString();
			System.out.println("responseStr = " + responseStr);
			
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

			user = mapper.readValue(responseString.toString(), User.class);
			
			System.out.println("---" + user.toString());
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return user;

	}

	public List<User> getUsers() {

		List<User> uList = new ArrayList<>();
		User user1 = new User();
		user1.setEmail("test1@gmail.com");
		user1.setFirst_name("test1FN");
		user1.setLast_name("test1LN");

		User user2 = new User();
		user2.setEmail("test2@gmail.com");
		user2.setFirst_name("test2FN");
		user2.setLast_name("test2LN");

		User user3 = new User();
		user3.setEmail("test3@gmail.com");
		user3.setFirst_name("test3FN");
		user3.setLast_name("test3LN");
		uList.add(user1);

		uList.add(user2);
		uList.add(user3);
		return uList;

	}

	public List<Group> viewGroups() {
		Group groups = new Group();
		List<Group> groupData = new ArrayList<Group>();
		try {
			Credentials credentials = new UsernamePasswordCredentials("kvishwanath@snaplogic.com", "Pavan@kalyan1");
			Header authenticate = BasicScheme.authenticate(credentials, UTF_8, false);
			HttpClient httpClient = HttpClientBuilder.create().build();
			String url = "https://elastic.snaplogic.com:443/api/1/rest/public/groups/" + "Snap-COE-Development";
			HttpGet httpGet = new HttpGet(url);
			httpGet.setHeader(authenticate);
			HttpResponse response = httpClient.execute(httpGet);
			BufferedReader breader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			StringBuilder responseString = new StringBuilder();
			String line = "";
			while ((line = breader.readLine()) != null) {
				responseString.append(line);
			}
			breader.close();
			String responseStr = responseString.toString();

			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

			groups = mapper.readValue(responseString.toString(), Group.class);

			if (groups.getGroups() != null && groups.getGroups().length > 0) {
				for (String groupName : groups.getGroups()) {
					Group group = new Group(groupName);
					groupData.add(group);
				}
			}
			/*
			 * for (String group : groups.getGroupName()) {
			 * usersData.add(getUserCompleteDetails(userEmailId)); }
			 */
			/*
			 * System.out.println("The users object data is ");
			 * System.out.println(users.getName());
			 * System.out.println(users.getMembers().size());
			 * System.out.println(users.getMembers());
			 * System.out.println("The users object data is ");
			 * System.out.println("responseStr = " + responseStr);
			 */

		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return groupData;

	}

	public Users getMembers() {
		Users users = new Users();
		List<User> usersData = new ArrayList<>();
		try {
			Credentials credentials = new UsernamePasswordCredentials("kvishwanath@snaplogic.com", "Pavan@kalyan1");
			Header authenticate = BasicScheme.authenticate(credentials, UTF_8, false);
			HttpClient client4 = HttpClientBuilder.create().build();
			String url = "https://elastic.snaplogic.com:443/api/1/rest/public/groups/" + "Snap-COE-Development"
					+ "/members";
			HttpGet httpGet = new HttpGet(url);
			httpGet.setHeader(authenticate);
			HttpResponse response = client4.execute(httpGet);
			BufferedReader breader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			StringBuilder responseString = new StringBuilder();
			String line = "";
			while ((line = breader.readLine()) != null) {
				responseString.append(line);
			}
			breader.close();
			String responseStr = responseString.toString();

			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

			users = mapper.readValue(responseString.toString(), Users.class);

		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return users;

	}

	public Users getGroupDetails(String groupName) {
		Users users = new Users();
		try {
			Credentials credentials = new UsernamePasswordCredentials("kvishwanath@snaplogic.com", "Pavan@kalyan1");
			Header authenticate = BasicScheme.authenticate(credentials, UTF_8, false);
			HttpClient client4 = HttpClientBuilder.create().build();

			String url = "https://elastic.snaplogic.com:443/api/1/rest/public/groups/Snap-COE-Development/" + groupName;
			HttpGet httpGet = new HttpGet(url);
			httpGet.setHeader(authenticate);
			HttpResponse response = client4.execute(httpGet);
			BufferedReader breader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			StringBuilder responseString = new StringBuilder();
			String line = "";
			while ((line = breader.readLine()) != null) {
				responseString.append(line);
			}
			breader.close();
			String responseStr = responseString.toString();

			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

			users = mapper.readValue(responseString.toString(), Users.class);
			System.out.println("responseStr = " + responseStr);
			System.out.println("---" + users.toString());
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return users;

	}
}
